// Début de votre relation : 12 août 2026 à 00:00:00.
// Le format ci-dessous évite les problèmes de fuseau horaire sur iPhone.
const startDate = new Date(2026, 7, 12, 0, 0, 0);

function updateCounter() {
  const now = new Date();
  let diff = now.getTime() - startDate.getTime();

  if (diff < 0) diff = 0;

  const second = 1000;
  const minute = 60 * second;
  const hour = 60 * minute;
  const day = 24 * hour;

  const days = Math.floor(diff / day);
  diff -= days * day;

  const hours = Math.floor(diff / hour);
  diff -= hours * hour;

  const minutes = Math.floor(diff / minute);
  diff -= minutes * minute;

  const seconds = Math.floor(diff / second);

  document.getElementById("counter").textContent =
    `${days} jour${days !== 1 ? "s" : ""} · ${hours} h · ${minutes} min · ${seconds} s`;
}

updateCounter();
setInterval(updateCounter, 1000);

// Lettre
const letterBtn = document.getElementById("letterBtn");
const letter = document.getElementById("letter");

letterBtn.addEventListener("click", () => {
  letter.classList.toggle("hidden");
  letterBtn.textContent = letter.classList.contains("hidden")
    ? "💌 Une lettre pour toi"
    : "💌 Refermer la lettre";
});

// Musique
const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");

musicBtn.addEventListener("click", async () => {
  try {
    if (music.paused) {
      await music.play();
      musicBtn.textContent = "🔇 Couper la musique";
    } else {
      music.pause();
      musicBtn.textContent = "🎵 Activer la musique ❤️";
    }
  } catch (error) {
    musicBtn.textContent = "🎵 Appuie encore pour lancer la musique";
  }
});

// Cœurs
function createHeart() {
  const el = document.createElement("div");
  el.className = "heart";
  el.textContent = ["❤️","💕","💗","💖","💘"][Math.floor(Math.random() * 5)];
  el.style.left = Math.random() * 100 + "vw";
  el.style.fontSize = (12 + Math.random() * 18) + "px";
  el.style.animationDuration = (5 + Math.random() * 5) + "s";
  document.getElementById("hearts").appendChild(el);
  setTimeout(() => el.remove(), 10000);
}
setInterval(createHeart, 650);

// Étoiles
for (let i = 0; i < 22; i++) {
  const s = document.createElement("div");
  s.className = "spark";
  s.style.left = Math.random() * 100 + "vw";
  s.style.top = Math.random() * 100 + "vh";
  s.style.animationDelay = Math.random() * 2 + "s";
  document.getElementById("sparkles").appendChild(s);
}
